# HK Blogger (self-hosted)

A tiny blog server. HTML files dropped in become posts. Only the owner email can sign in and manage content.

## How it works
- Visitors see the post list at `/`. Each post opens at `/p/<file>.html`.
- Owner signs in at `/admin`: enter `OWNER_EMAIL`, receive a one-time link by email (valid 15 min), then drag and drop files.
- `.html` files become posts. Other files (images, video, PDF) are stored in `files/` and served at `/files/<name>` for use inside posts.
- Upload limit per file: 100 MB (`MAX_UPLOAD_MB`).
- You can also drop `.html` files straight into the `posts/` folder on the server; they appear automatically.

## Run
```
npm install
cp .env.example .env     # edit values
node --env-file=.env server.js    # Node 20+
```
Without SMTP settings, the sign-in link is printed in the server console.

## Deploy on a VPS with your domain (www.hkblogger.com)
1. Point the domain's A record at the server IP.
2. Run the app with a process manager (e.g. `pm2 start server.js --name hkblogger`).
3. Put a reverse proxy with HTTPS in front (Caddy is simplest):
```
www.hkblogger.com {
    request_body { max_size 100MB }
    reverse_proxy localhost:3000
}
```
4. Set `SITE_URL=https://www.hkblogger.com` in `.env`.

Back up the `posts/` and `files/` folders regularly.
