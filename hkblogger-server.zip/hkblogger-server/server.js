const express = require('express');
const multer = require('multer');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const SITE_URL = (process.env.SITE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const OWNER = (process.env.OWNER_EMAIL || '').trim().toLowerCase();
const SECRET = process.env.SECRET || '';
const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 100);
if (!OWNER || !SECRET) { console.error('Set OWNER_EMAIL and SECRET (see .env.example)'); process.exit(1); }

const POSTS = path.join(__dirname, 'posts');   // HTML files = blog posts
const FILES = path.join(__dirname, 'files');   // images, videos, PDFs, etc.
fs.mkdirSync(POSTS, { recursive: true });
fs.mkdirSync(FILES, { recursive: true });

const mailer = process.env.SMTP_HOST ? nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 465),
  secure: Number(process.env.SMTP_PORT || 465) === 465,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
}) : null;

// ---------- helpers ----------
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sign = v => crypto.createHmac('sha256', SECRET).update(v).digest('hex');
const makeToken = (kind, ttlMs) => { const p = `${kind}.${Date.now() + ttlMs}.${crypto.randomBytes(8).toString('hex')}`; return `${p}.${sign(p)}`; };
function checkToken(tok, kind) {
  const parts = String(tok || '').split('.');
  if (parts.length !== 4 || parts[0] !== kind) return false;
  const p = parts.slice(0, 3).join('.');
  const a = Buffer.from(sign(p)), b = Buffer.from(parts[3]);
  return a.length === b.length && crypto.timingSafeEqual(a, b) && Number(parts[1]) > Date.now();
}
const cookies = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(x => x[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
const isAdmin = req => checkToken(cookies(req).session, 's');
const requireAdmin = (req, res, next) => isAdmin(req) ? next() : res.redirect('/admin');
const safeName = n => path.basename(n).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'file';
function uniqueName(dir, name) {
  const ext = path.extname(name), base = path.basename(name, ext); let n = name, i = 1;
  while (fs.existsSync(path.join(dir, n))) n = `${base}-${i++}${ext}`;
  return n;
}
function listPosts() {
  return fs.readdirSync(POSTS).filter(f => /\.html?$/i.test(f)).map(f => {
    const full = path.join(POSTS, f), st = fs.statSync(full);
    const head = fs.readFileSync(full, 'utf8').slice(0, 20000);
    const t = (head.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || head.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1];
    const title = (t || f.replace(/\.html?$/i, '')).replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim() || f;
    return { file: f, title, date: st.mtimeMs };
  }).sort((a, b) => b.date - a.date);
}

// ---------- page shell ----------
const css = `:root{--bg:#faf8f5;--fg:#1d1b19;--mut:#6f6a64;--card:#fff;--bd:#e4dfd8;--ac:#b4472f}
@media(prefers-color-scheme:dark){:root{--bg:#171513;--fg:#f0ece6;--mut:#a39d95;--card:#201d1a;--bd:#34302b;--ac:#e8836b;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:17px/1.6 Georgia,serif}
.wrap{max-width:760px;margin:0 auto;padding:24px 18px 60px}
header{display:flex;justify-content:space-between;align-items:baseline;border-bottom:1px solid var(--bd);padding-bottom:14px;margin-bottom:24px}
header a.logo{color:var(--fg);text-decoration:none;font-size:28px;font-weight:700}
header a,.meta{font:14px system-ui,sans-serif;color:var(--mut)}
.card{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:16px 18px;margin-bottom:12px;display:flex;justify-content:space-between;gap:12px;align-items:center}
.card h2{margin:0 0 4px;font-size:21px}.card h2 a{color:var(--fg);text-decoration:none}
button,.btn{font:600 14px system-ui,sans-serif;background:var(--ac);color:#fff;border:0;border-radius:8px;padding:8px 14px;cursor:pointer}
button.ghost{background:transparent;color:var(--mut);border:1px solid var(--bd)}
input[type=email]{font:16px system-ui;padding:10px;border:1px solid var(--bd);border-radius:8px;width:100%;max-width:340px;background:var(--card);color:var(--fg)}
#drop{border:2px dashed var(--bd);border-radius:12px;padding:22px;text-align:center;color:var(--mut);font:15px system-ui;margin-bottom:20px}
#drop.over{border-color:var(--ac);color:var(--ac)}.note{font:14px system-ui;color:var(--mut)}code{background:var(--card);padding:1px 5px;border-radius:4px}`;
const page = (title, body, admin) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>${css}</style></head><body><div class="wrap"><header><a class="logo" href="/">HK Blogger</a><a href="/admin">${admin ? 'Admin' : ''}</a></header>${body}</div></body></html>`;

// ---------- app ----------
const app = express();
app.disable('x-powered-by');
app.use(express.urlencoded({ extended: false }));

app.get('/', (req, res) => {
  const posts = listPosts();
  const body = posts.length ? posts.map(p => `<div class="card"><div><h2><a href="/p/${encodeURIComponent(p.file)}">${esc(p.title)}</a></h2><div class="meta">${new Date(p.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</div></div></div>`).join('') : '<p class="note" style="text-align:center;padding:40px 0">No posts yet.</p>';
  res.send(page('HK Blogger', body, isAdmin(req)));
});

// Posts are uploaded only by the owner, so they are served as-is.
app.get('/p/:file', (req, res) => {
  const f = path.basename(req.params.file);
  const full = path.join(POSTS, f);
  if (!/\.html?$/i.test(f) || !fs.existsSync(full)) return res.status(404).send(page('Not found', '<p>Post not found.</p>'));
  res.sendFile(full);
});
app.use('/files', express.static(FILES, { index: false, setHeaders: r => r.setHeader('X-Content-Type-Options', 'nosniff') }));

// ---- email-controlled sign-in ----
const attempts = new Map();
app.post('/login', async (req, res) => {
  const ip = req.ip, now = Date.now();
  const recent = (attempts.get(ip) || []).filter(t => now - t < 15 * 60 * 1000);
  if (recent.length >= 5) return res.status(429).send(page('Slow down', '<p>Too many attempts. Try again later.</p>'));
  attempts.set(ip, [...recent, now]);
  const email = String(req.body.email || '').trim().toLowerCase();
  if (email === OWNER) {
    const link = `${SITE_URL}/auth?t=${encodeURIComponent(makeToken('m', 15 * 60 * 1000))}`;
    try {
      if (mailer) await mailer.sendMail({ from: process.env.SMTP_USER, to: OWNER, subject: 'Your HK Blogger sign-in link', text: `Sign in (valid 15 minutes):\n${link}` });
      else console.log('SMTP not configured. Sign-in link:', link);
    } catch (e) { console.error('Mail error:', e.message); }
  }
  res.send(page('Check your email', '<p>If that email is authorised, a sign-in link has been sent. It is valid for 15 minutes.</p>'));
});
const usedLinks = new Set();
app.get('/auth', (req, res) => {
  const t = String(req.query.t || '');
  if (!checkToken(t, 'm') || usedLinks.has(t)) return res.status(400).send(page('Invalid link', '<p>This link is invalid or expired. <a href="/admin">Request a new one</a>.</p>'));
  usedLinks.add(t);
  const secure = SITE_URL.startsWith('https') ? '; Secure' : '';
  res.setHeader('Set-Cookie', `session=${encodeURIComponent(makeToken('s', 30 * 864e5))}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${30 * 86400}${secure}`);
  res.redirect('/admin');
});
app.post('/logout', (req, res) => { res.setHeader('Set-Cookie', 'session=; HttpOnly; Path=/; Max-Age=0'); res.redirect('/'); });

// ---- admin ----
app.get('/admin', (req, res) => {
  if (!isAdmin(req)) return res.send(page('Sign in', `<h2>Owner sign-in</h2><p class="note">Enter the owner email. A one-time sign-in link will be sent to it.</p><form method="post" action="/login"><input type="email" name="email" placeholder="you@example.com" required> <button>Send link</button></form>`));
  const posts = listPosts();
  const rows = posts.map(p => `<div class="card"><div><h2><a href="/p/${encodeURIComponent(p.file)}">${esc(p.title)}</a></h2><div class="meta">${esc(p.file)}</div></div><form method="post" action="/delete/${encodeURIComponent(p.file)}" onsubmit="return confirm('Delete this post?')"><button class="ghost">Delete</button></form></div>`).join('') || '<p class="note">No posts yet.</p>';
  const assets = fs.readdirSync(FILES).map(f => `<div class="meta"><code>/files/${esc(f)}</code></div>`).join('');
  res.send(page('Admin', `
  <div id="drop">Drop <b>.html</b> files to publish as posts, or images/videos/PDFs to host them (max ${MAX_MB} MB each)
  <p><button id="pick" type="button">Choose files</button></p><input id="f" type="file" multiple hidden></div>
  <p class="note" id="msg"></p>${rows}
  <h3>Media files</h3>${assets || '<p class="note">None yet. Use these links inside your posts.</p>'}
  <form method="post" action="/logout" style="margin-top:30px"><button class="ghost">Sign out</button></form>
  <script>
  const d=document.getElementById('drop'),f=document.getElementById('f'),m=document.getElementById('msg');
  document.getElementById('pick').onclick=()=>f.click();f.onchange=()=>up(f.files);
  d.ondragover=e=>{e.preventDefault();d.classList.add('over')};d.ondragleave=()=>d.classList.remove('over');
  d.ondrop=e=>{e.preventDefault();d.classList.remove('over');up(e.dataTransfer.files)};
  async function up(files){const fd=new FormData();for(const x of files)fd.append('files',x);m.textContent='Uploading...';
   try{const r=await fetch('/upload',{method:'POST',body:fd});const j=await r.json();m.textContent=j.message||'Done.';if(r.ok)setTimeout(()=>location.reload(),700)}catch(e){m.textContent='Upload failed.'}}
  </script>`, true));
});

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, /\.html?$/i.test(file.originalname) ? POSTS : FILES),
    filename: (req, file, cb) => { const dir = /\.html?$/i.test(file.originalname) ? POSTS : FILES; cb(null, uniqueName(dir, safeName(file.originalname))); }
  }),
  limits: { fileSize: MAX_MB * 1024 * 1024 }
}).array('files', 50);
app.post('/upload', requireAdmin, (req, res) => upload(req, res, err => {
  if (err) return res.status(400).json({ message: err.code === 'LIMIT_FILE_SIZE' ? `File too large (limit ${MAX_MB} MB).` : 'Upload error.' });
  const n = (req.files || []).length;
  res.json({ message: `${n} file(s) uploaded.` });
}));
app.post('/delete/:file', requireAdmin, (req, res) => {
  const full = path.join(POSTS, path.basename(req.params.file));
  if (fs.existsSync(full)) fs.unlinkSync(full);
  res.redirect('/admin');
});

app.listen(PORT, () => console.log(`HK Blogger running on ${SITE_URL} (port ${PORT})`));
